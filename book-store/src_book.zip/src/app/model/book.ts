export class Book {
    public bcode:number;
	public title:string;
	public price:number;
	public category:string;
	public type:string;
}
